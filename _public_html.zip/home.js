gsap.registerPlugin(ScrollTrigger, CustomEase);
//HERO ANIMATION//
var hero = document.querySelector('.hero');
var logo = document.querySelector('.logosvg');
var heroLight = document.querySelector('.hero-light');
var heroXtra = document.querySelector('#heroeXtra');

////////////////////////////////////////////


hero.addEventListener('mousemove', logoMove);

function logoMove(e) {

const heroWidthSetter = hero.offsetWidth;

if (heroWidthSetter > 992) {
    var heroWidth = hero.offsetWidth;
    var heroHeight = hero.offsetHeight;
    var setBlur = 6;
    var opacitea = 1;
}

if (heroWidthSetter < 992 && heroWidthSetter > 768) {
    var heroWidth = hero.offsetWidth * 1.2;
    var heroHeight = hero.offsetHeight * 1.2;
    var setBlur = 4;
    var opacitea = .75;
}

if (heroWidthSetter < 768) {
    var heroWidth = (hero.offsetWidth * 1.3);
    var heroHeight = (hero.offsetHeight * 1.3);
    var setBlur = 4;
    var opacitea = .75;
}
const centerX = hero.offsetLeft + heroWidth / 2;
const centerY = hero.offsetTop + heroHeight / 2;
//
const heroMouseX = ((e.clientX - centerX) / 9 / heroWidth * 105).toFixed(1);
const heroMouseY = ((e.clientY - centerY) / 9 / heroHeight * 106).toFixed(1);
//
const heroMouseOpposeX = heroMouseX * -1;
const heroMouseOpposeY = heroMouseY * -1;

//const heroMouseXper = ((e.clientX - centerX)/6/heroWidth*1205).toFixed(0);
//const heroMouseYper = ((e.clientY - centerY)/6/heroHeight*1208).toFixed(0);

const heroMouseYper2 = ((e.clientY) / 20).toFixed(2);
const heroXtraX = (heroMouseX / 1).toFixed(2);

    ////////////////////////////////////////////

heroLight.style.transform = `translateX(${e.pageX}px) translateY(${e.pageY}px)`;
$('#lineargradient').attr('x1', heroXtraX);
$(heroXtra).attr('offset', heroMouseYper2 + '%');

    ////////////////////////////////////////////

this.querySelectorAll('.logosvg').forEach(logoSvg => {
logoSvg.style.filter = `drop-shadow(${heroMouseOpposeX}px ${heroMouseOpposeY}px ${setBlur}px rgba(119, 119, 119, ${opacitea})) drop-shadow(${heroMouseX}px ${heroMouseY}px ${setBlur}px rgba(17, 17, 17, ${opacitea}))`;
    });

}
//closeing logoMove
//END HERO ANIMATION//


// SECTIONs SCROLL TRANSITION

let hs1In = gsap.timeline({
scrollTrigger: {
    trigger: ".hs1",
    start: "25% 65%",
    end: "85% 50%",
    scrub: 1
}
})
.from('.hs1-card', {
    y: "50%",
    opacity: 0,
    duration: 6,
    stagger: 6.5
})
.to('.hs1-card', {
    y: "-50%",
    opacity: 0,
    duration: 6,
    stagger: 6.5
});

let hs3In = gsap.timeline({
    scrollTrigger: {
    trigger:'.hs3',
    start: '-5% center',
    end: '100% 100%',
    scrub: 1
    }
    })
    .from('.ppl-card:nth-child(1),.ppl-card:nth-child(2),.ppl-card:nth-child(3)', {
    x: "25%",
    opacity: 0,
    duration: 6,
    stagger: 2
    });
// END OF SECTIONs SCROLL TRANSITION

CustomEase.create("customEase", "M0,0 C0.126,0.382 0.335,1.01 0.5,1 0.665,0.99 0.876,0.382 1,0");

gsap.utils.toArray('.card-test').forEach((section, i) => {
gsap.timeline({
    scrollTrigger: {
      trigger: '.card-test-2',
      start: "top 70% ",
      end: "top",
      scrub: true,
      pinSpacing: false,
      //markers:true,
      onUpdate: (self) => {
        const progress = self.progress;
        gsap.to(section, { opacity: 1 - progress * 0.65, overwrite: 'auto' , ease: "elastic.out(1,0.3)"});
        }
    }
  })
  .fromTo(section, { y: "0px" }, { y: "250px" });


  ScrollTrigger.create({
    trigger: '.card-test-2',
    start: "top 25%", // Inicia el cambio de borde radial cuando el top de la sección esté cerca del tope de la pantalla
    end: "top 10%", // Completa el cambio de borde radial cuando el top de la sección toque el tope de la pantalla
    scrub: true,
    //markers: true,
    onUpdate: (self) => {
      const progress = self.progress;
      gsap.to('.card-test-2', { borderTopLeftRadius: `${3.125 - 3.125*progress }vw`, borderTopRightRadius: `${3.125 - 3.125*progress}vw`, overwrite: 'auto' });
    }
  });

});

// Escuchar el evento de redimensionamiento y refrescar ScrollTrigger con debounce
window.addEventListener('resize', () => {
  
  const currentWidth = window.innerWidth;
  const currentHeight = window.innerHeight;

  // Definir un umbral para el cambio significativo
  const widthThreshold = 10; // Cambiar según sea necesario
  const heightThreshold = 10; // Cambiar según sea necesario

  // Verificar si el cambio en el tamaño del viewport es significativo
  if (Math.abs(currentWidth - previousWidth) > widthThreshold || Math.abs(currentHeight - previousHeight) > heightThreshold) {
    // Recargar la página
    window.location.reload();
  } else {
    // Refrescar ScrollTrigger
    ScrollTrigger.refresh();
  }

  // Actualizar el tamaño anterior del viewport
  previousWidth = currentWidth;
  previousHeight = currentHeight;
});
//pin choose-section
gsap.timeline({
  scrollTrigger: {
    pin: '.choose-section',
    ease: "none",
    trigger: '.choose-section',
    start: 'top', // Inicia la animación cada 300px
    end: `+=${window.innerHeight * 4}`,
    scrub: true,
    //markers: true,
    pinSpacing: true,
  }
});
  
//advantage 1
ScrollTrigger.create({
  trigger: '.choose-section',
  start: () => 'top ', // Inicia la animación cada 300px
  end: () => 'top -100%', // Termina la animación después de 300px
  scrub: true,
  //markers: true,
  overwrite: 'auto',
  //pinSpacing: true,
  onUpdate: (self) => {
    const progress = self.progress;
    const vh = window.innerHeight / 100;
    const startFade = 0.2; // 10% del progreso
    const endFade = 0.8; // 90% del progreso
    let opacity;

    if (progress < startFade) {
      opacity = progress / startFade;
    } else if (progress > endFade) {
      opacity = (1 - progress) / (1 - endFade);
    } else {
      opacity = 1;
    }
    gsap.to( '.advantage-1', {opacity: opacity,  });
  }

})
//advantage 2
ScrollTrigger.create({
  trigger: '.advantage-1',
  start:  'top -85%', // Inicia la animación cada 300px
  end: 'top -185%', // Termina la animación después de 300px
  scrub: true,
  //markers: true,
  overwrite: 'auto',
  //pinSpacing: true,
  onUpdate: (self) => {
    const progress = self.progress;
    const vh = window.innerHeight / 100;
    const startFade = 0.2; // 10% del progreso
    const endFade = 0.8; // 90% del progreso
    let opacity;

    if (progress < startFade) {
      opacity = progress / startFade;
    } else if (progress > endFade) {
      opacity = (1 - progress) / (1 - endFade);
    } else {
      opacity = 1;
    }
    gsap.to( '.advantage-2', {opacity: opacity,  });
  }

})
//advantage 3
ScrollTrigger.create({
  trigger: '.advantage-2',
  start:  'top -165%', // Inicia la animación cada 300px
  end: 'top -265%', // Termina la animación después de 300px
  scrub: true,
  //markers: true,
  overwrite: 'auto',
  //pinSpacing: true,
  onUpdate: (self) => {
    const progress = self.progress;
    const vh = window.innerHeight / 100;
    const startFade = 0.2; // 10% del progreso
    const endFade = 0.8; // 90% del progreso
    let opacity;

    if (progress < startFade) {
      opacity = progress / startFade;
    } else if (progress > endFade) {
      opacity = (1 - progress) / (1 - endFade);
    } else {
      opacity = 1;
    }
    gsap.to( '.advantage-3', {opacity: opacity,  });
  }

});



const lenis = new Lenis();

// Synchronize Lenis scrolling with GSAP's ScrollTrigger plugin
lenis.on('scroll', ScrollTrigger.update);

// Add Lenis's requestAnimationFrame (raf) method to GSAP's ticker
// This ensures Lenis's smooth scroll animation updates on each GSAP tick
gsap.ticker.add((time) => {
  lenis.raf(time * 1000); // Convert time from seconds to milliseconds
});

// Disable lag smoothing in GSAP to prevent any delay in scroll animations
gsap.ticker.lagSmoothing(0);
