gsap.registerPlugin(ScrollTrigger, CustomEase);
//HERO ANIMATION//
var hero = document.querySelector('.hero');
var logo = document.querySelector('.logosvg');
var heroLight = document.querySelector('.hero-light');
var heroXtra = document.querySelector('#heroeXtra');

////////////////////////////////////////////


hero.addEventListener('mousemove', logoMove);

function logoMove(e) {

const heroWidthSetter = hero.offsetWidth;

if (heroWidthSetter > 992) {
    var heroWidth = hero.offsetWidth;
    var heroHeight = hero.offsetHeight;
    var setBlur = 6;
    var opacitea = 1;
}

if (heroWidthSetter < 992 && heroWidthSetter > 768) {
    var heroWidth = hero.offsetWidth * 1.2;
    var heroHeight = hero.offsetHeight * 1.2;
    var setBlur = 4;
    var opacitea = .75;
}

if (heroWidthSetter < 768) {
    var heroWidth = (hero.offsetWidth * 1.3);
    var heroHeight = (hero.offsetHeight * 1.3);
    var setBlur = 4;
    var opacitea = .75;
}
const centerX = hero.offsetLeft + heroWidth / 2;
const centerY = hero.offsetTop + heroHeight / 2;
//
const heroMouseX = ((e.clientX - centerX) / 9 / heroWidth * 105).toFixed(1);
const heroMouseY = ((e.clientY - centerY) / 9 / heroHeight * 106).toFixed(1);
//
const heroMouseOpposeX = heroMouseX * -1;
const heroMouseOpposeY = heroMouseY * -1;

//const heroMouseXper = ((e.clientX - centerX)/6/heroWidth*1205).toFixed(0);
//const heroMouseYper = ((e.clientY - centerY)/6/heroHeight*1208).toFixed(0);

const heroMouseYper2 = ((e.clientY) / 20).toFixed(2);
const heroXtraX = (heroMouseX / 1).toFixed(2);

    ////////////////////////////////////////////

heroLight.style.transform = `translateX(${e.pageX}px) translateY(${e.pageY}px)`;
$('#lineargradient').attr('x1', heroXtraX);
$(heroXtra).attr('offset', heroMouseYper2 + '%');

    ////////////////////////////////////////////

this.querySelectorAll('.logosvg').forEach(logoSvg => {
logoSvg.style.filter = `drop-shadow(${heroMouseOpposeX}px ${heroMouseOpposeY}px ${setBlur}px rgba(119, 119, 119, ${opacitea})) drop-shadow(${heroMouseX}px ${heroMouseY}px ${setBlur}px rgba(17, 17, 17, ${opacitea}))`;
    });

}
//closeing logoMove
//END HERO ANIMATION//


// SECTIONs SCROLL TRANSITION



// Crear una línea de tiempo de GSAP
const timeline = gsap.timeline();

timeline.to('.choose-section',{
  scrollTrigger: {
  trigger: '.choose-section',
  start: 'top ',
  end: '400% top',
  scrub: true,
  pin: true,
  pinSpacing: true,
  //markers: true,
  overwrite: 'auto',
}
});

// Añadir el primer ScrollTrigger a la línea de tiempo
timeline.to('.card-test', {
  ease: "elastic.out(1,0.3)",
  scrollTrigger: {
    trigger: '.content',
    start: "-60% top",
    end: "top",
    scrub: true,
    //markers: true,
    onUpdate: (self) => {
      const progress = self.progress;
      gsap.to('.card-test', { opacity: 1 - progress * 0.65, overwrite: 'auto', ease: "elastic.out(1,0.3)" });
      gsap.to('.card-test', { y: `${progress * 200}px`, overwrite: 'auto',  });
      gsap.to('.card-test-2', { borderTopLeftRadius: `${3.125 - 3.125 * progress}vw`, borderTopRightRadius: `${3.125 - 3.125 * progress}vw`, overwrite: 'auto' });
    }
  }
});

//advantage 1
timeline.to('.advantage-1', {
  scrollTrigger: {
  trigger: '.content',
  start:  'top', // Inicia la animación cada 300px
  end:  '135%', // Termina la animación después de 300px
  //markers: true,
  onUpdate: (self) => {
    const progress = self.progress;
    const vh = window.innerHeight / 100;
    const startFade = 0.2; // 10% del progreso
    const endFade = 0.8; // 90% del progreso
    let opacity;

    if (progress < startFade) {
      opacity = progress / startFade;
    } else if (progress > endFade) {
      opacity = (1 - progress) / (1 - endFade);
    } else {
      opacity = 1;
    }
    gsap.to( '.advantage-1', {opacity: opacity,  overwrite: 'auto' });
  }
}
});

//advantage 2
timeline.to('.advantage-2', {
  scrollTrigger: {
  trigger: '.content',
  start:  '135%', // Inicia la animación cada 300px
  end:  '265%', // Termina la animación después de 300px
  //markers: true,
  onUpdate: (self) => {
    const progress = self.progress;
    const vh = window.innerHeight / 100;
    const startFade = 0.2; // 10% del progreso
    const endFade = 0.8; // 90% del progreso
    let opacity;

    if (progress < startFade) {
      opacity = progress / startFade;
    } else if (progress > endFade) {
      opacity = (1 - progress) / (1 - endFade);
    } else {
      opacity = 1;
    }
    gsap.to( '.advantage-2', {opacity: opacity,  overwrite: 'auto' });
  }
}
});

//advantage 3
timeline.to('.advantage-3', {
  scrollTrigger: {
  trigger: '.content',
  start:  '265%', // Inicia la animación cada 300px
  end:  '390%', // Termina la animación después de 300px
  //markers: true,
  onUpdate: (self) => {
    const progress = self.progress;
    const vh = window.innerHeight / 100;
    const startFade = 0.2; // 10% del progreso
    const endFade = 0.8; // 90% del progreso
    let opacity;

    if (progress < startFade) {
      opacity = progress / startFade;
    } else if (progress > endFade) {
      opacity = (1 - progress) / (1 - endFade);
    } else {
      opacity = 1;
    }
    gsap.to( '.advantage-3', {opacity: opacity,  overwrite: 'auto' });
  }
}
});


  
function handleOrientationChange() {
  window.location.reload();
}
// Escuchar el evento de cambio de orientación
window.addEventListener('orientationchange', handleOrientationChange);


const lenis = new Lenis();

// Synchronize Lenis scrolling with GSAP's ScrollTrigger plugin
lenis.on('scroll', ScrollTrigger.update);

// Add Lenis's requestAnimationFrame (raf) method to GSAP's ticker
// This ensures Lenis's smooth scroll animation updates on each GSAP tick

gsap.ticker.add((time) => {
  lenis.raf(time * 1000); // Convert time from seconds to milliseconds
});

// Disable lag smoothing in GSAP to prevent any delay in scroll animations
gsap.ticker.lagSmoothing(0);
